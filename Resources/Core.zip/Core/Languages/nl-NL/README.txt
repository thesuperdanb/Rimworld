NL-Rimworld
===========

Dutch translation of Rimworld

All copyrights are owned by Ludeon studios. License info here: http://ludeon.com/forums/index.php?topic=2933

Translators:
-Ser-Geeves
-ConfusedWings
