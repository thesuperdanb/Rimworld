RimWorld-ja
===========

Japanese localization for RimWorld

See this page for license info:

http://ludeon.com/forums/index.php?topic=2933.0
