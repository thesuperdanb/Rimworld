RimWorld-it

I will be on vacation until July 20th, so the translation will remain this way until I return :)
===========

Italian localization for RimWorld

See this page for license info:

http://ludeon.com/forums/index.php?topic=2933.0
