RimWorld_de
===========

A German translation for RimWorld.

See this page for license info:

http://ludeon.com/forums/index.php?topic=2933.0
