Spanish-translation-of-Rimworld
===============================

This is the Spanish translation of Rimworld.

See this page for license info:

http://ludeon.com/forums/index.php?topic=2933.0

--------------------

Primary contributors:

-Vhiden
